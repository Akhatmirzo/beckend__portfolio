import React from 'react'

export const CheckHomework = () => {
  return (
    <div>CheckHomework</div>
  )
}
