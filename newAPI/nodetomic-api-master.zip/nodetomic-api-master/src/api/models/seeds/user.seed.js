export default [
  {
    username: 'admin',
    password: '$2a$10$f.iNtPrK9Y69p1KRWcQai.UIBdFoOBpeEGMRA2odDsKptgSi4a4xe', // 123
    email: 'floyd@admin.com',
    name: 'Pink',
    lastname: 'Floyd',
    roles: ['admin']
  }, {
    username: 'user',
    password: '$2a$10$wQVXH2NGe8V.LRv5s7QopubLnQAo7jJpx52RdBnckbK1QnHxNi/YK', // 123
    email: 'peppers@user.com',
    name: 'Chilli',
    lastname: 'Peppers',
    roles: ['user']
  }
];